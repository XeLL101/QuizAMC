import React, { useState } from 'react';
import { StyleSheet, View, Text, TextInput, Button, FlatList, TouchableOpacity } from 'react-native';
import { styles } from './styles'; 
import DeleteButton from './DeleteButton';
import HideButton from './HideButton';
import EditButton from './EditButton';

export default function App() {
  const [enteredGoalText, setEnteredGoalText] = useState('');
  const [courseGoals, setCourseGoals] = useState([]);
  const [editingIndex, setEditingIndex] = useState(null);

  const goalInputHandler = (enteredText) => {
    setEnteredGoalText(enteredText);
  };

  const addGoalHandler = () => {
    if (editingIndex !== null) {
      // If editing, update the existing goal
      const updatedGoals = [...courseGoals];
      updatedGoals[editingIndex].text = enteredGoalText;
      setCourseGoals(updatedGoals);
      setEditingIndex(null);
    } else {
      // If not editing, add a new goal
      setCourseGoals((currentCourseGoals) => [...currentCourseGoals, { text: enteredGoalText, isVisible: true }]);
    }
    setEnteredGoalText('');
  };

  const iDeleteMo = (index) => {
    const updatedGoals = [...courseGoals];
    updatedGoals.splice(index, 1);
    setCourseGoals(updatedGoals);
  };

  const itagoMoAko = (index) => {
    const updatedGoals = [...courseGoals];
    updatedGoals[index].isVisible = !updatedGoals[index].isVisible;
    setCourseGoals(updatedGoals);
  };

  const startEditing = (index) => {
    setEnteredGoalText(courseGoals[index].text);
    setEditingIndex(index);
  };

  const getRainbowColor = (index) => {
    const colors = ['#FDF7E4', '#BBAB8C', '#776B5D', '#B4B4B8', '#E3E1D9', '#ADBC9F', '#436850']; // Rainbow colors
    return { backgroundColor: colors[index % colors.length] };
  };

  return (
    <View style={styles.appContainer}>
      <View style={styles.inputContainer}>
        <TextInput
          style={styles.textInput}
          placeholder="My Goal"
          onChangeText={goalInputHandler}
          value={enteredGoalText}
        />
        <Button title={editingIndex !== null ? "Edit Goal" : "Add Goal"} onPress={addGoalHandler} />
      </View>

      <FlatList
        data={courseGoals}
        renderItem={({ item, index }) => (
          <View style={[styles.goalsContainer, getRainbowColor(index)]}>
            <Text style={styles.textF}>
              {item.isVisible ? item.text : '************'}
            </Text>
            <View style={styles.buttonsContainer}>
              <DeleteButton onPress={() => iDeleteMo(index)} />
              <HideButton onPress={() => itagoMoAko(index)} isVisible={item.isVisible} />
              <EditButton onPress={() => startEditing(index)} />
            </View>
          </View>
        )}
        keyExtractor={(item, index) => index.toString()}
        alwaysBounceVertical={false}
      />
    </View>
  );
}

