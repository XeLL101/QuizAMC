import React from 'react';
import { TouchableOpacity, Text } from 'react-native';
import { styles } from './styles';


export const DeleteButton = ({ onPress }) => (

  <TouchableOpacity onPress={onPress}>
    <Text style={styles.deleteButton}>X</Text>
  </TouchableOpacity>
);

export default DeleteButton;


              