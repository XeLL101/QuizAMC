import React from 'react';
import { TouchableOpacity, Text } from 'react-native';
import { styles } from './styles';

const HideButton = ({ onPress, isVisible }) => (
  <TouchableOpacity onPress={onPress}>
    <Text style={styles.hideButton}>{isVisible ? 'HIDE' : 'SHOW'}</Text>
  </TouchableOpacity>
);

export default HideButton;