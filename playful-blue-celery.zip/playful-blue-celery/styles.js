import {StyleSheet} from 'react-native';


export const styles = StyleSheet.create({
  appContainer: {
    flex: 1,
    paddingTop: 50,
    paddingHorizontal: 16,
  },

  inputContainer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingBottom: 25,
    borderBottomWidth: 1,
    borderColor: '#CCCC',
  },

  textInput: {
    borderWidth: 1,
    width: '70%',
    marginRight: 8,
    padding: 8,
  },

  goalsContainer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingTop: 20,
    padding: 10,
  },

  textF: {
    fontSize: 20,
  },

  buttonsContainer: {
    flexDirection: 'row',
    position: 'absolute',
    right: 10,
  },

  deleteButton: {
    color: 'black',
    fontSize: 20,
    marginLeft: 10,
  },

  hideButton: {
    color: 'Black',
    fontSize: 20,
    marginLeft: 10,
  },

  // Added style for the EDIT button
  editButton: {
    color: 'Black',
    fontSize: 20,
    marginLeft: 10,
  },
});